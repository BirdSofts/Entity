﻿// *******************************************************************************************
/// <summary>
/// 
/// </summary>
/// <created>ʆϒʅ,04.10.2019</created>
/// <changed>ʆϒʅ,06.10.2019</changed>
// *******************************************************************************************

#ifndef GTESTSCLASS_H
#define GTESTSCLASS_H


#include <gtest/gtest.h>
#include "../libSettings/settings.h"


class EntityTest : public testing::Test
{


};


#endif // !GTESTSCLASS_H
